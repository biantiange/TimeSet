package com.example.lt.timeset_andorid.Login;

public class Constant {
    public static final String IP ="";

}
